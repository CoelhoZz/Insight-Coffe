﻿using InsightCoffe.Repositorios;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace InsightCoffe
{
    public class AdicionarPedido
    {
        public AdicionarPedido(uint codeBar, string produto, int quantidade )
        {
            

        }

    }
}
