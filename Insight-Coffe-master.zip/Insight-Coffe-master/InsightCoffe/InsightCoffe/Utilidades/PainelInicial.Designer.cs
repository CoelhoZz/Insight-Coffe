﻿namespace InsightCoffe.Utilidades
{
    partial class PainelInicial
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PainelInicial));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.ferramentasMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.pagamentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pedidosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.produtosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.notepadStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.fecharTodosStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.consultasMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.RegPagamentosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RegPedidosToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.RegProdutosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.RegClientToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printSetupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.editMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.undoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.selectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolBarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusBarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.contentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.indexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusBarra = new System.Windows.Forms.StatusStrip();
            this.toolStrip_lblusuario = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.panelCabecalho = new System.Windows.Forms.Panel();
            this.btnMostrarAplicações = new System.Windows.Forms.Button();
            this.picFotoUsuario = new System.Windows.Forms.PictureBox();
            this.btnFechar = new System.Windows.Forms.Button();
            this.btnMinimizar = new System.Windows.Forms.Button();
            this.lblUsuarioLogado = new System.Windows.Forms.Label();
            this.btnNormal = new System.Windows.Forms.Button();
            this.bntMaximizar = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelTempo = new System.Windows.Forms.Panel();
            this.picIconeRelogio = new System.Windows.Forms.PictureBox();
            this.lblRelogio = new System.Windows.Forms.Label();
            this.timerTempoReal = new System.Windows.Forms.Timer(this.components);
            this.panelAplicações = new System.Windows.Forms.Panel();
            this.btnProdutos = new XanderUI.XUIButton();
            this.btnVendas = new XanderUI.XUIButton();
            this.btnPagamento = new XanderUI.XUIButton();
            this.menuStrip.SuspendLayout();
            this.statusBarra.SuspendLayout();
            this.panelCabecalho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFotoUsuario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelTempo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picIconeRelogio)).BeginInit();
            this.panelAplicações.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(150)))), ((int)(((byte)(64)))));
            this.menuStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip.Font = new System.Drawing.Font("Malgun Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip.GripMargin = new System.Windows.Forms.Padding(2, 50, 0, 2);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ferramentasMenu,
            this.consultasMenu,
            this.editMenu,
            this.viewMenu,
            this.helpMenu});
            this.menuStrip.Location = new System.Drawing.Point(199, 97);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(464, 33);
            this.menuStrip.TabIndex = 2;
            this.menuStrip.Text = "MenuStrip";
            this.menuStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip_ItemClicked);
            // 
            // ferramentasMenu
            // 
            this.ferramentasMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pagamentoToolStripMenuItem,
            this.pedidosToolStripMenuItem,
            this.produtosToolStripMenuItem,
            this.toolStripSeparator2,
            this.notepadStripMenuItem4,
            this.toolStripSeparator1,
            this.fecharTodosStripMenuItem3,
            this.toolStripSeparator9});
            this.ferramentasMenu.Name = "ferramentasMenu";
            this.ferramentasMenu.Size = new System.Drawing.Size(130, 29);
            this.ferramentasMenu.Text = "&Ferramentas";
            // 
            // pagamentoToolStripMenuItem
            // 
            this.pagamentoToolStripMenuItem.Name = "pagamentoToolStripMenuItem";
            this.pagamentoToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.pagamentoToolStripMenuItem.Size = new System.Drawing.Size(248, 30);
            this.pagamentoToolStripMenuItem.Text = "Pagamento";
            this.pagamentoToolStripMenuItem.Click += new System.EventHandler(this.pagamentosToolStripMenuItem_Click);
            // 
            // pedidosToolStripMenuItem
            // 
            this.pedidosToolStripMenuItem.Name = "pedidosToolStripMenuItem";
            this.pedidosToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F8;
            this.pedidosToolStripMenuItem.Size = new System.Drawing.Size(248, 30);
            this.pedidosToolStripMenuItem.Text = "Pedido";
            this.pedidosToolStripMenuItem.Click += new System.EventHandler(this.pedidosToolStripMenuItem_Click);
            // 
            // produtosToolStripMenuItem
            // 
            this.produtosToolStripMenuItem.Name = "produtosToolStripMenuItem";
            this.produtosToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F7;
            this.produtosToolStripMenuItem.Size = new System.Drawing.Size(248, 30);
            this.produtosToolStripMenuItem.Text = "Produto";
            this.produtosToolStripMenuItem.Click += new System.EventHandler(this.produtosToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(245, 6);
            // 
            // notepadStripMenuItem4
            // 
            this.notepadStripMenuItem4.Name = "notepadStripMenuItem4";
            this.notepadStripMenuItem4.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.notepadStripMenuItem4.Size = new System.Drawing.Size(248, 30);
            this.notepadStripMenuItem4.Text = "Bloco de Notas";
            this.notepadStripMenuItem4.Click += new System.EventHandler(this.BlocoAnotaçõestoolStripMenuItem4_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(245, 6);
            // 
            // fecharTodosStripMenuItem3
            // 
            this.fecharTodosStripMenuItem3.Name = "fecharTodosStripMenuItem3";
            this.fecharTodosStripMenuItem3.Size = new System.Drawing.Size(248, 30);
            this.fecharTodosStripMenuItem3.Text = "Fec&har todos";
            this.fecharTodosStripMenuItem3.Click += new System.EventHandler(this.CloseAllToolStripMenuItem_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(245, 6);
            // 
            // consultasMenu
            // 
            this.consultasMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RegPagamentosToolStripMenuItem,
            this.RegPedidosToolStripMenuItem2,
            this.RegProdutosToolStripMenuItem1,
            this.toolStripSeparator3,
            this.RegClientToolStripMenuItem,
            this.toolStripSeparator4,
            this.printToolStripMenuItem,
            this.printPreviewToolStripMenuItem,
            this.printSetupToolStripMenuItem,
            this.toolStripSeparator5});
            this.consultasMenu.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder;
            this.consultasMenu.Name = "consultasMenu";
            this.consultasMenu.Size = new System.Drawing.Size(107, 29);
            this.consultasMenu.Text = "&Consultas";
            // 
            // RegPagamentosToolStripMenuItem
            // 
            this.RegPagamentosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("RegPagamentosToolStripMenuItem.Image")));
            this.RegPagamentosToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.RegPagamentosToolStripMenuItem.Name = "RegPagamentosToolStripMenuItem";
            this.RegPagamentosToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F9)));
            this.RegPagamentosToolStripMenuItem.Size = new System.Drawing.Size(371, 30);
            this.RegPagamentosToolStripMenuItem.Text = "Registro de Pagamentos";
            this.RegPagamentosToolStripMenuItem.Click += new System.EventHandler(this.RegPagamentosToolStripMenuItem_Click);
            // 
            // RegPedidosToolStripMenuItem2
            // 
            this.RegPedidosToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("RegPedidosToolStripMenuItem2.Image")));
            this.RegPedidosToolStripMenuItem2.ImageTransparentColor = System.Drawing.Color.Black;
            this.RegPedidosToolStripMenuItem2.Name = "RegPedidosToolStripMenuItem2";
            this.RegPedidosToolStripMenuItem2.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F8)));
            this.RegPedidosToolStripMenuItem2.Size = new System.Drawing.Size(371, 30);
            this.RegPedidosToolStripMenuItem2.Text = "Registro de Pedidos";
            this.RegPedidosToolStripMenuItem2.Click += new System.EventHandler(this.RegPedidostoolStripMenuItem2_Click);
            // 
            // RegProdutosToolStripMenuItem1
            // 
            this.RegProdutosToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("RegProdutosToolStripMenuItem1.Image")));
            this.RegProdutosToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Black;
            this.RegProdutosToolStripMenuItem1.Name = "RegProdutosToolStripMenuItem1";
            this.RegProdutosToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F7)));
            this.RegProdutosToolStripMenuItem1.Size = new System.Drawing.Size(371, 30);
            this.RegProdutosToolStripMenuItem1.Text = "Registro de Produtos";
            this.RegProdutosToolStripMenuItem1.Click += new System.EventHandler(this.RegProdutostoolStripMenuItem1_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(368, 6);
            // 
            // RegClientToolStripMenuItem
            // 
            this.RegClientToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("RegClientToolStripMenuItem.Image")));
            this.RegClientToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.RegClientToolStripMenuItem.Name = "RegClientToolStripMenuItem";
            this.RegClientToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F6;
            this.RegClientToolStripMenuItem.Size = new System.Drawing.Size(371, 30);
            this.RegClientToolStripMenuItem.Text = "Registro de Clientes";
            this.RegClientToolStripMenuItem.Click += new System.EventHandler(this.RegClientestoolStripMenuItem1_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(368, 6);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("printToolStripMenuItem.Image")));
            this.printToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.printToolStripMenuItem.Size = new System.Drawing.Size(371, 30);
            this.printToolStripMenuItem.Text = "Im&primir";
            this.printToolStripMenuItem.Visible = false;
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("printPreviewToolStripMenuItem.Image")));
            this.printPreviewToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(371, 30);
            this.printPreviewToolStripMenuItem.Text = "&Vizualizar impressão";
            this.printPreviewToolStripMenuItem.Visible = false;
            // 
            // printSetupToolStripMenuItem
            // 
            this.printSetupToolStripMenuItem.Name = "printSetupToolStripMenuItem";
            this.printSetupToolStripMenuItem.Size = new System.Drawing.Size(371, 30);
            this.printSetupToolStripMenuItem.Text = "Configurar Impressão";
            this.printSetupToolStripMenuItem.Visible = false;
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(368, 6);
            this.toolStripSeparator5.Visible = false;
            // 
            // editMenu
            // 
            this.editMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undoToolStripMenuItem,
            this.redoToolStripMenuItem,
            this.toolStripSeparator6,
            this.cutToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem,
            this.toolStripSeparator7,
            this.selectAllToolStripMenuItem});
            this.editMenu.Name = "editMenu";
            this.editMenu.Size = new System.Drawing.Size(74, 29);
            this.editMenu.Text = "&Editar";
            // 
            // undoToolStripMenuItem
            // 
            this.undoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("undoToolStripMenuItem.Image")));
            this.undoToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.undoToolStripMenuItem.Name = "undoToolStripMenuItem";
            this.undoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.undoToolStripMenuItem.Size = new System.Drawing.Size(291, 30);
            this.undoToolStripMenuItem.Text = "&Desfazer";
            // 
            // redoToolStripMenuItem
            // 
            this.redoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("redoToolStripMenuItem.Image")));
            this.redoToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.redoToolStripMenuItem.Name = "redoToolStripMenuItem";
            this.redoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y)));
            this.redoToolStripMenuItem.Size = new System.Drawing.Size(291, 30);
            this.redoToolStripMenuItem.Text = "&Refazer";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(288, 6);
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("cutToolStripMenuItem.Image")));
            this.cutToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            this.cutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.cutToolStripMenuItem.Size = new System.Drawing.Size(291, 30);
            this.cutToolStripMenuItem.Text = "&Recortar";
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("copyToolStripMenuItem.Image")));
            this.copyToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(291, 30);
            this.copyToolStripMenuItem.Text = "&Copiar";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.copyToolStripMenuItem_Click);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pasteToolStripMenuItem.Image")));
            this.pasteToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(291, 30);
            this.pasteToolStripMenuItem.Text = "&Colar";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(288, 6);
            // 
            // selectAllToolStripMenuItem
            // 
            this.selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
            this.selectAllToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.selectAllToolStripMenuItem.Size = new System.Drawing.Size(291, 30);
            this.selectAllToolStripMenuItem.Text = "Selecion&ar Tudo";
            // 
            // viewMenu
            // 
            this.viewMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolBarToolStripMenuItem,
            this.statusBarToolStripMenuItem});
            this.viewMenu.Name = "viewMenu";
            this.viewMenu.Size = new System.Drawing.Size(71, 29);
            this.viewMenu.Text = "&Exibir";
            // 
            // toolBarToolStripMenuItem
            // 
            this.toolBarToolStripMenuItem.Checked = true;
            this.toolBarToolStripMenuItem.CheckOnClick = true;
            this.toolBarToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolBarToolStripMenuItem.Name = "toolBarToolStripMenuItem";
            this.toolBarToolStripMenuItem.Size = new System.Drawing.Size(270, 30);
            this.toolBarToolStripMenuItem.Text = "&Barra de Ferramentas";
            this.toolBarToolStripMenuItem.Click += new System.EventHandler(this.ToolBarToolStripMenuItem_Click);
            // 
            // statusBarToolStripMenuItem
            // 
            this.statusBarToolStripMenuItem.Checked = true;
            this.statusBarToolStripMenuItem.CheckOnClick = true;
            this.statusBarToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.statusBarToolStripMenuItem.Name = "statusBarToolStripMenuItem";
            this.statusBarToolStripMenuItem.Size = new System.Drawing.Size(270, 30);
            this.statusBarToolStripMenuItem.Text = "&Barra de Status";
            this.statusBarToolStripMenuItem.Click += new System.EventHandler(this.StatusBarToolStripMenuItem_Click);
            // 
            // helpMenu
            // 
            this.helpMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contentsToolStripMenuItem,
            this.indexToolStripMenuItem,
            this.toolStripSeparator8,
            this.aboutToolStripMenuItem});
            this.helpMenu.Name = "helpMenu";
            this.helpMenu.Size = new System.Drawing.Size(74, 29);
            this.helpMenu.Text = "&Ajuda";
            // 
            // contentsToolStripMenuItem
            // 
            this.contentsToolStripMenuItem.Name = "contentsToolStripMenuItem";
            this.contentsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F1)));
            this.contentsToolStripMenuItem.Size = new System.Drawing.Size(243, 30);
            this.contentsToolStripMenuItem.Text = "&Conteúdo";
            // 
            // indexToolStripMenuItem
            // 
            this.indexToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("indexToolStripMenuItem.Image")));
            this.indexToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.indexToolStripMenuItem.Name = "indexToolStripMenuItem";
            this.indexToolStripMenuItem.Size = new System.Drawing.Size(243, 30);
            this.indexToolStripMenuItem.Text = "&Índice";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(240, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(243, 30);
            this.aboutToolStripMenuItem.Text = "&Sobre ... ...";
            // 
            // statusBarra
            // 
            this.statusBarra.BackColor = System.Drawing.Color.SaddleBrown;
            this.statusBarra.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStrip_lblusuario,
            this.toolStripStatusLabel1});
            this.statusBarra.Location = new System.Drawing.Point(0, 670);
            this.statusBarra.Name = "statusBarra";
            this.statusBarra.Size = new System.Drawing.Size(1252, 22);
            this.statusBarra.TabIndex = 2;
            this.statusBarra.Text = "StatusStrip";
            // 
            // toolStrip_lblusuario
            // 
            this.toolStrip_lblusuario.BackColor = System.Drawing.SystemColors.Control;
            this.toolStrip_lblusuario.ForeColor = System.Drawing.Color.Goldenrod;
            this.toolStrip_lblusuario.Name = "toolStrip_lblusuario";
            this.toolStrip_lblusuario.Size = new System.Drawing.Size(53, 17);
            this.toolStrip_lblusuario.Text = "Usuario: ";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // panelCabecalho
            // 
            this.panelCabecalho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(150)))), ((int)(((byte)(64)))));
            this.panelCabecalho.Controls.Add(this.btnMostrarAplicações);
            this.panelCabecalho.Controls.Add(this.picFotoUsuario);
            this.panelCabecalho.Controls.Add(this.btnFechar);
            this.panelCabecalho.Controls.Add(this.btnMinimizar);
            this.panelCabecalho.Controls.Add(this.lblUsuarioLogado);
            this.panelCabecalho.Controls.Add(this.menuStrip);
            this.panelCabecalho.Controls.Add(this.btnNormal);
            this.panelCabecalho.Controls.Add(this.bntMaximizar);
            this.panelCabecalho.Controls.Add(this.pictureBox1);
            this.panelCabecalho.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelCabecalho.Location = new System.Drawing.Point(0, 0);
            this.panelCabecalho.Name = "panelCabecalho";
            this.panelCabecalho.Size = new System.Drawing.Size(1252, 140);
            this.panelCabecalho.TabIndex = 0;
            // 
            // btnMostrarAplicações
            // 
            this.btnMostrarAplicações.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(150)))), ((int)(((byte)(64)))));
            this.btnMostrarAplicações.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMostrarAplicações.BackgroundImage")));
            this.btnMostrarAplicações.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMostrarAplicações.FlatAppearance.BorderSize = 0;
            this.btnMostrarAplicações.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMostrarAplicações.Location = new System.Drawing.Point(0, 26);
            this.btnMostrarAplicações.Name = "btnMostrarAplicações";
            this.btnMostrarAplicações.Size = new System.Drawing.Size(204, 114);
            this.btnMostrarAplicações.TabIndex = 1;
            this.btnMostrarAplicações.UseVisualStyleBackColor = false;
            this.btnMostrarAplicações.Click += new System.EventHandler(this.bntMostrarAplicações_Click);
            // 
            // picFotoUsuario
            // 
            this.picFotoUsuario.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picFotoUsuario.Image = ((System.Drawing.Image)(resources.GetObject("picFotoUsuario.Image")));
            this.picFotoUsuario.Location = new System.Drawing.Point(1165, 44);
            this.picFotoUsuario.Name = "picFotoUsuario";
            this.picFotoUsuario.Size = new System.Drawing.Size(64, 50);
            this.picFotoUsuario.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picFotoUsuario.TabIndex = 59;
            this.picFotoUsuario.TabStop = false;
            // 
            // btnFechar
            // 
            this.btnFechar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFechar.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnFechar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnFechar.BackgroundImage")));
            this.btnFechar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnFechar.FlatAppearance.BorderColor = System.Drawing.Color.SaddleBrown;
            this.btnFechar.FlatAppearance.BorderSize = 5;
            this.btnFechar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btnFechar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btnFechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFechar.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnFechar.Location = new System.Drawing.Point(1230, -1);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(22, 26);
            this.btnFechar.TabIndex = 6;
            this.btnFechar.UseVisualStyleBackColor = false;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            this.btnFechar.MouseLeave += new System.EventHandler(this.LeaveFechar);
            this.btnFechar.MouseMove += new System.Windows.Forms.MouseEventHandler(this.controlFechar);
            // 
            // btnMinimizar
            // 
            this.btnMinimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimizar.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnMinimizar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMinimizar.BackgroundImage")));
            this.btnMinimizar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMinimizar.FlatAppearance.BorderColor = System.Drawing.Color.SaddleBrown;
            this.btnMinimizar.FlatAppearance.BorderSize = 5;
            this.btnMinimizar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro;
            this.btnMinimizar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnMinimizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimizar.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnMinimizar.Location = new System.Drawing.Point(1180, 0);
            this.btnMinimizar.Name = "btnMinimizar";
            this.btnMinimizar.Size = new System.Drawing.Size(24, 25);
            this.btnMinimizar.TabIndex = 4;
            this.btnMinimizar.UseVisualStyleBackColor = false;
            this.btnMinimizar.Click += new System.EventHandler(this.btnMinimizar_Click);
            this.btnMinimizar.MouseLeave += new System.EventHandler(this.LeaveMinimizar);
            this.btnMinimizar.MouseMove += new System.Windows.Forms.MouseEventHandler(this.controlMinimizar);
            // 
            // lblUsuarioLogado
            // 
            this.lblUsuarioLogado.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblUsuarioLogado.AutoSize = true;
            this.lblUsuarioLogado.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsuarioLogado.Location = new System.Drawing.Point(1161, 97);
            this.lblUsuarioLogado.Name = "lblUsuarioLogado";
            this.lblUsuarioLogado.Size = new System.Drawing.Size(74, 20);
            this.lblUsuarioLogado.TabIndex = 3;
            this.lblUsuarioLogado.Text = "Gerente";
            this.lblUsuarioLogado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnNormal
            // 
            this.btnNormal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNormal.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnNormal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnNormal.BackgroundImage")));
            this.btnNormal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNormal.FlatAppearance.BorderColor = System.Drawing.Color.SaddleBrown;
            this.btnNormal.FlatAppearance.BorderSize = 5;
            this.btnNormal.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro;
            this.btnNormal.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnNormal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNormal.Location = new System.Drawing.Point(1205, 0);
            this.btnNormal.Name = "btnNormal";
            this.btnNormal.Size = new System.Drawing.Size(24, 25);
            this.btnNormal.TabIndex = 5;
            this.btnNormal.UseVisualStyleBackColor = false;
            this.btnNormal.Click += new System.EventHandler(this.btnNormal_Click);
            this.btnNormal.MouseLeave += new System.EventHandler(this.LeaveNormal);
            this.btnNormal.MouseMove += new System.Windows.Forms.MouseEventHandler(this.controlNormal);
            // 
            // bntMaximizar
            // 
            this.bntMaximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bntMaximizar.BackColor = System.Drawing.Color.SaddleBrown;
            this.bntMaximizar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bntMaximizar.BackgroundImage")));
            this.bntMaximizar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bntMaximizar.FlatAppearance.BorderColor = System.Drawing.Color.SaddleBrown;
            this.bntMaximizar.FlatAppearance.BorderSize = 6;
            this.bntMaximizar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro;
            this.bntMaximizar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.bntMaximizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bntMaximizar.Location = new System.Drawing.Point(1205, 0);
            this.bntMaximizar.Name = "bntMaximizar";
            this.bntMaximizar.Size = new System.Drawing.Size(24, 25);
            this.bntMaximizar.TabIndex = 55;
            this.bntMaximizar.UseVisualStyleBackColor = false;
            this.bntMaximizar.Visible = false;
            this.bntMaximizar.Click += new System.EventHandler(this.bntMaximizar_Click);
            this.bntMaximizar.MouseLeave += new System.EventHandler(this.LeaveMaximizar);
            this.bntMaximizar.MouseMove += new System.Windows.Forms.MouseEventHandler(this.controlMaximizar);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.SaddleBrown;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1252, 25);
            this.pictureBox1.TabIndex = 46;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form_MouseUp);
            // 
            // panelTempo
            // 
            this.panelTempo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panelTempo.BackColor = System.Drawing.Color.SaddleBrown;
            this.panelTempo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelTempo.Controls.Add(this.picIconeRelogio);
            this.panelTempo.Controls.Add(this.lblRelogio);
            this.panelTempo.Location = new System.Drawing.Point(31, 461);
            this.panelTempo.Name = "panelTempo";
            this.panelTempo.Size = new System.Drawing.Size(135, 55);
            this.panelTempo.TabIndex = 1;
            // 
            // picIconeRelogio
            // 
            this.picIconeRelogio.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picIconeRelogio.Image = ((System.Drawing.Image)(resources.GetObject("picIconeRelogio.Image")));
            this.picIconeRelogio.Location = new System.Drawing.Point(83, 3);
            this.picIconeRelogio.Name = "picIconeRelogio";
            this.picIconeRelogio.Size = new System.Drawing.Size(47, 42);
            this.picIconeRelogio.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picIconeRelogio.TabIndex = 66;
            this.picIconeRelogio.TabStop = false;
            // 
            // lblRelogio
            // 
            this.lblRelogio.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblRelogio.AutoSize = true;
            this.lblRelogio.Font = new System.Drawing.Font("Agency FB", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRelogio.Location = new System.Drawing.Point(15, 4);
            this.lblRelogio.Name = "lblRelogio";
            this.lblRelogio.Size = new System.Drawing.Size(84, 42);
            this.lblRelogio.TabIndex = 0;
            this.lblRelogio.Text = "00:00";
            this.lblRelogio.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timerTempoReal
            // 
            this.timerTempoReal.Enabled = true;
            this.timerTempoReal.Interval = 1000;
            // 
            // panelAplicações
            // 
            this.panelAplicações.BackColor = System.Drawing.Color.DimGray;
            this.panelAplicações.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelAplicações.Controls.Add(this.btnProdutos);
            this.panelAplicações.Controls.Add(this.panelTempo);
            this.panelAplicações.Controls.Add(this.btnVendas);
            this.panelAplicações.Controls.Add(this.btnPagamento);
            this.panelAplicações.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelAplicações.Location = new System.Drawing.Point(0, 140);
            this.panelAplicações.Name = "panelAplicações";
            this.panelAplicações.Size = new System.Drawing.Size(204, 530);
            this.panelAplicações.TabIndex = 1;
            this.panelAplicações.Visible = false;
            // 
            // btnProdutos
            // 
            this.btnProdutos.BackgroundColor = System.Drawing.Color.DimGray;
            this.btnProdutos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnProdutos.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnProdutos.ButtonImage")));
            this.btnProdutos.ButtonStyle = XanderUI.XUIButton.Style.Material;
            this.btnProdutos.ButtonText = "Produtos";
            this.btnProdutos.ClickBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(75)))), ((int)(((byte)(80)))));
            this.btnProdutos.ClickTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(130)))), ((int)(((byte)(140)))));
            this.btnProdutos.CornerRadius = 5;
            this.btnProdutos.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.btnProdutos.Horizontal_Alignment = System.Drawing.StringAlignment.Center;
            this.btnProdutos.HoverBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(80)))), ((int)(((byte)(90)))));
            this.btnProdutos.HoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(215)))));
            this.btnProdutos.ImagePosition = XanderUI.XUIButton.imgPosition.Left;
            this.btnProdutos.Location = new System.Drawing.Point(6, 182);
            this.btnProdutos.Name = "btnProdutos";
            this.btnProdutos.Size = new System.Drawing.Size(186, 69);
            this.btnProdutos.TabIndex = 3;
            this.btnProdutos.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(200)))), ((int)(((byte)(185)))));
            this.btnProdutos.Vertical_Alignment = System.Drawing.StringAlignment.Center;
            this.btnProdutos.Click += new System.EventHandler(this.bntProdutos_Click);
            // 
            // btnVendas
            // 
            this.btnVendas.BackgroundColor = System.Drawing.Color.DimGray;
            this.btnVendas.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnVendas.ButtonImage")));
            this.btnVendas.ButtonStyle = XanderUI.XUIButton.Style.Material;
            this.btnVendas.ButtonText = "Pedidos";
            this.btnVendas.ClickBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(200)))), ((int)(((byte)(185)))));
            this.btnVendas.ClickTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(200)))), ((int)(((byte)(185)))));
            this.btnVendas.CornerRadius = 5;
            this.btnVendas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.btnVendas.Horizontal_Alignment = System.Drawing.StringAlignment.Center;
            this.btnVendas.HoverBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(200)))), ((int)(((byte)(185)))));
            this.btnVendas.HoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(70)))), ((int)(((byte)(75)))));
            this.btnVendas.ImagePosition = XanderUI.XUIButton.imgPosition.Left;
            this.btnVendas.Location = new System.Drawing.Point(6, 106);
            this.btnVendas.Name = "btnVendas";
            this.btnVendas.Size = new System.Drawing.Size(186, 69);
            this.btnVendas.TabIndex = 2;
            this.btnVendas.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(200)))), ((int)(((byte)(185)))));
            this.btnVendas.Vertical_Alignment = System.Drawing.StringAlignment.Center;
            this.btnVendas.Click += new System.EventHandler(this.bntVendas_Click_1);
            // 
            // btnPagamento
            // 
            this.btnPagamento.BackgroundColor = System.Drawing.Color.DimGray;
            this.btnPagamento.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnPagamento.ButtonImage")));
            this.btnPagamento.ButtonStyle = XanderUI.XUIButton.Style.Material;
            this.btnPagamento.ButtonText = "Pagamentos";
            this.btnPagamento.ClickBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(75)))), ((int)(((byte)(80)))));
            this.btnPagamento.ClickTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(130)))), ((int)(((byte)(140)))));
            this.btnPagamento.CornerRadius = 5;
            this.btnPagamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.btnPagamento.Horizontal_Alignment = System.Drawing.StringAlignment.Center;
            this.btnPagamento.HoverBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(80)))), ((int)(((byte)(90)))));
            this.btnPagamento.HoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(215)))));
            this.btnPagamento.ImagePosition = XanderUI.XUIButton.imgPosition.Left;
            this.btnPagamento.Location = new System.Drawing.Point(6, 29);
            this.btnPagamento.Name = "btnPagamento";
            this.btnPagamento.Size = new System.Drawing.Size(186, 69);
            this.btnPagamento.TabIndex = 1;
            this.btnPagamento.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(200)))), ((int)(((byte)(185)))));
            this.btnPagamento.Vertical_Alignment = System.Drawing.StringAlignment.Center;
            this.btnPagamento.Click += new System.EventHandler(this.bntPagamento_Click_1);
            // 
            // PainelInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1252, 692);
            this.Controls.Add(this.panelAplicações);
            this.Controls.Add(this.statusBarra);
            this.Controls.Add(this.panelCabecalho);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "PainelInicial";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PainelInicial";
            this.TransparencyKey = System.Drawing.Color.Transparent;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.PainelInicial_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusBarra.ResumeLayout(false);
            this.statusBarra.PerformLayout();
            this.panelCabecalho.ResumeLayout(false);
            this.panelCabecalho.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFotoUsuario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelTempo.ResumeLayout(false);
            this.panelTempo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picIconeRelogio)).EndInit();
            this.panelAplicações.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusBarra;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem printSetupToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripStatusLabel toolStrip_lblusuario;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultasMenu;
        private System.Windows.Forms.ToolStripMenuItem RegClientToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem RegPagamentosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editMenu;
        private System.Windows.Forms.ToolStripMenuItem undoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewMenu;
        private System.Windows.Forms.ToolStripMenuItem toolBarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem statusBarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ferramentasMenu;
        private System.Windows.Forms.ToolStripMenuItem pagamentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpMenu;
        private System.Windows.Forms.ToolStripMenuItem contentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem indexToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Panel panelCabecalho;
        private System.Windows.Forms.Label lblUsuarioLogado;
        private System.Windows.Forms.Panel panelTempo;
        private System.Windows.Forms.ToolStripMenuItem pedidosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem produtosToolStripMenuItem;
        private System.Windows.Forms.Label lblRelogio;
        private System.Windows.Forms.PictureBox picIconeRelogio;
        private System.Windows.Forms.Timer timerTempoReal;
        private System.Windows.Forms.PictureBox picFotoUsuario;
        private System.Windows.Forms.Panel panelAplicações;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.Button btnMinimizar;
        private System.Windows.Forms.Button bntMaximizar;
        private System.Windows.Forms.Button btnNormal;
        private System.Windows.Forms.PictureBox pictureBox1;
        private XanderUI.XUIButton btnProdutos;
        private XanderUI.XUIButton btnVendas;
        private XanderUI.XUIButton btnPagamento;
        private System.Windows.Forms.Button btnMostrarAplicações;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem notepadStripMenuItem4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem fecharTodosStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem RegPedidosToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem RegProdutosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
    }
}



